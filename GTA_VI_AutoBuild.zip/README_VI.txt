GTA VI — OFFLINE VISUAL DEMO
===========================

This is a fictional fan-made menu prototype. It is not an official Rockstar
product and contains no GTA game files, gameplay, or official artwork.

BUILD ON A MAC
--------------
1. Install Xcode.
2. Create a new iOS App project named "GTA VI" (SwiftUI, Swift).
3. Set Bundle Identifier to: com.demo.gtavi
4. Replace the generated ContentView.swift with GTA VI/ContentView.swift.
5. Add the @main app entry point from that file, or replace the generated
   app file with the same file's GTAVI_DemoApp declaration (do not keep two
   @main declarations).
6. Set the deployment target to iOS 16 or later.
7. In Signing & Capabilities, select your Apple development team.
8. Choose a connected iPhone or Any iOS Device (arm64), then Product > Archive.
9. In Organizer, choose Distribute App > Development or Ad Hoc, then export.
10. If exporting an IPA for ESign, use a provisioning profile compatible
    with the target device and signing certificate. Import the exported IPA
    into ESign and sign/install it with the matching certificate/profile.

IMPORTANT
---------
- An IPA must be built and signed on macOS with Xcode (or another valid
  Apple toolchain). This environment cannot sign an iOS IPA.
- ESign cannot turn Swift source into an IPA; it signs an already-built IPA.
- For a photo-only prank, keep the "fictional fan-made" note in the app.
- App icon can be added in Xcode: Assets.xcassets > AppIcon.
