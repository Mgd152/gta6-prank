import SwiftUI

@main
struct GTAVI_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

struct ContentView: View {
    @State private var showStory = false
    @State private var showSettings = false

    private let pink = Color(red: 1.0, green: 0.25, blue: 0.57)
    private let cyan = Color(red: 0.20, green: 0.88, blue: 0.95)

    var body: some View {
        GeometryReader { geo in
            ZStack {
                LinearGradient(
                    colors: [
                        Color(red: 0.10, green: 0.08, blue: 0.23),
                        Color(red: 0.30, green: 0.08, blue: 0.30),
                        Color(red: 0.04, green: 0.13, blue: 0.24)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                // Neon sunset
                Circle()
                    .fill(
                        LinearGradient(colors: [pink, Color.orange],
                                       startPoint: .top, endPoint: .bottom)
                    )
                    .frame(width: geo.size.width * 0.78)
                    .blur(radius: 1)
                    .offset(x: geo.size.width * 0.20, y: -geo.size.height * 0.19)
                    .opacity(0.82)

                VStack(spacing: 0) {
                    HStack {
                        Text("ROCKSTAR-STYLE FAN CONCEPT")
                            .font(.system(size: 9, weight: .heavy, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(.white.opacity(0.72))
                        Spacer()
                        Text("DEMO BUILD")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .tracking(1.4)
                            .foregroundStyle(cyan)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 18)

                    Spacer(minLength: 24)

                    VStack(spacing: -8) {
                        Text("GRAND THEFT")
                            .font(.system(size: min(geo.size.width * 0.105, 43),
                                          weight: .black, design: .rounded))
                            .tracking(-1.8)
                            .foregroundStyle(.white)
                            .shadow(color: .black.opacity(0.55), radius: 8, x: 2, y: 5)

                        HStack(spacing: 7) {
                            Text("AUTO")
                                .font(.system(size: min(geo.size.width * 0.105, 43),
                                              weight: .black, design: .rounded))
                                .tracking(-1.8)
                                .foregroundStyle(.white)
                            Text("VI")
                                .font(.system(size: min(geo.size.width * 0.19, 78),
                                              weight: .black, design: .rounded))
                                .tracking(-4)
                                .foregroundStyle(
                                    LinearGradient(colors: [Color.white, Color(red: 1, green: 0.68, blue: 0.83)],
                                                   startPoint: .top, endPoint: .bottom)
                                )
                                .shadow(color: pink.opacity(0.8), radius: 14)
                        }
                    }
                    .padding(.bottom, 12)

                    Text("VICE CITY  •  STATE OF LEONIDA")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .tracking(2.3)
                        .foregroundStyle(.white.opacity(0.83))

                    Spacer()

                    VStack(spacing: 13) {
                        menuButton("STORY MODE", accent: pink) { showStory = true }
                        menuButton("SETTINGS", accent: cyan) { showSettings = true }
                        menuButton("QUIT GAME", accent: .white.opacity(0.75)) { }
                    }
                    .padding(.horizontal, 38)

                    Spacer()

                    HStack {
                        Text("FICTIONAL FAN-MADE UI")
                        Spacer()
                        Text("PRESS TO CONTINUE")
                    }
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(1.1)
                    .foregroundStyle(.white.opacity(0.55))
                    .padding(.horizontal, 24)
                    .padding(.bottom, 16)
                }

                // Decorative skyline silhouette
                VStack {
                    Spacer()
                    HStack(alignment: .bottom, spacing: 5) {
                        building(width: 30, height: 70)
                        building(width: 42, height: 112)
                        building(width: 25, height: 86)
                        building(width: 54, height: 145)
                        building(width: 34, height: 98)
                        building(width: 48, height: 122)
                        building(width: 26, height: 78)
                    }
                    .frame(maxWidth: .infinity)
                    .opacity(0.32)
                }
                .ignoresSafeArea(edges: .bottom)
                .allowsHitTesting(false)
            }
            .sheet(isPresented: $showStory) {
                DemoSheet(title: "STORY MODE", subtitle: "Your Vice City story starts here.", detail: "This is a visual-only demo. No game content is installed.")
                    .presentationDetents([.medium])
            }
            .sheet(isPresented: $showSettings) {
                DemoSheet(title: "SETTINGS", subtitle: "Display  •  Audio  •  Controls", detail: "All settings are decorative in this offline prototype.")
                    .presentationDetents([.medium])
            }
        }
    }

    private func menuButton(_ title: String, accent: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .tracking(2.2)
                Spacer()
                Image(systemName: "arrow.up.right")
                    .font(.system(size: 11, weight: .bold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 18)
            .frame(height: 53)
            .background(.ultraThinMaterial.opacity(0.75))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(accent.opacity(0.85), lineWidth: 1))
            .shadow(color: accent.opacity(0.18), radius: 12)
        }
        .buttonStyle(.plain)
    }

    private func building(width: CGFloat, height: CGFloat) -> some View {
        Rectangle()
            .fill(Color.black)
            .frame(width: width, height: height)
            .overlay(alignment: .top) {
                VStack(spacing: 8) {
                    ForEach(0..<4, id: \.self) { _ in
                        Rectangle().fill(cyan.opacity(0.55)).frame(height: 2)
                    }
                }
                .padding(.horizontal, 5)
                .padding(.top, 10)
            }
    }
}

struct DemoSheet: View {
    let title: String
    let subtitle: String
    let detail: String

    var body: some View {
        ZStack {
            Color(red: 0.08, green: 0.07, blue: 0.15).ignoresSafeArea()
            VStack(spacing: 18) {
                Text(title)
                    .font(.system(size: 26, weight: .black, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(Color.pink)
                Text(detail)
                    .font(.system(size: 12))
                    .foregroundStyle(.white.opacity(0.7))
                    .multilineTextAlignment(.center)
                Text("OFFLINE DEMO")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .tracking(2)
                    .foregroundStyle(.cyan)
            }
            .padding(28)
        }
    }
}
