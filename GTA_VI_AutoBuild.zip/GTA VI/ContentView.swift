import SwiftUI
@main struct GTAVI_DemoApp: App {
 var body: some Scene { WindowGroup { ContentView().preferredColorScheme(.dark) } }
}
struct ContentView: View {
 @State private var tab = "STORY"
 @State private var screen = ""
 @State private var selected = "Continue"
 @State private var progress = 0.0
 @State private var volume = 0.7
 @State private var quality = "High"
 let slides = ["Car", "Masks", "Sunset"]
 var body: some View {
 GeometryReader { g in
 let w = g.size.width
 let h = g.size.height
 ZStack {
 LinearGradient(colors:[Color(red:0.33,green:0.32,blue:0.57),Color(red:0.72,green:0.44,blue:0.64),Color(red:1,green:0.68,blue:0.39)],startPoint:.topLeading,endPoint:.bottomTrailing).ignoresSafeArea()
 if screen.isEmpty {
 VStack(spacing:h*0.025) {
 ZStack {
 HStack(spacing:5) { ForEach(["STORY","ONLINE"],id:\.self) { t in Button { tab=t } label: { Text(t).font(.system(size:13,weight:.medium)).foregroundColor(tab == t ? .black : .white).padding(.horizontal,20).frame(height:30).background(tab == t ? Color.white.opacity(0.8) : Color.black.opacity(0.28)).clipShape(Capsule()) }.buttonStyle(.plain) }; Spacer(); Text("FAN-MADE PRANK").font(.system(size:10,weight:.bold)).foregroundColor(.white) }
 Image("TopVI").resizable().scaledToFit().frame(height:32)
 }.frame(height:36)
 if tab == "STORY" {
 HStack(spacing:w*0.045) {
 VStack(spacing:h*0.025) {
 tile("Continue",w:w*0.49,h:h*0.38)
 HStack(spacing:w*0.025) { tile("Jason",w:w*0.2325,h:h*0.37);tile("Lucia",w:w*0.2325,h:h*0.37) }
 }
 VStack(spacing:h*0.035) { tile("Activities",w:w*0.42,h:h*0.23);tile("FreeMode",w:w*0.42,h:h*0.23);tile("Replay",w:w*0.42,h:h*0.23) }
 }.frame(maxWidth:.infinity,maxHeight:.infinity)
 } else { Spacer(); Text("ONLINE • OFFLINE FAN DEMO").font(.title2.bold()); Spacer() }
 HStack { Spacer(); Button { screen="Settings" } label: { Label("Settings",systemImage:"gearshape").padding(.horizontal,14).padding(.vertical,6).background(.black.opacity(0.32)).clipShape(Capsule()) }.buttonStyle(.plain) }.font(.system(size:13))
 }.padding(.horizontal,w*0.022).padding(.vertical,5)
 } else if screen == "Settings" {
 VStack(alignment:.leading,spacing:16) { Text("SETTINGS").font(.title.bold()); HStack { Text("Audio");Slider(value:$volume) }; Picker("Graphics",selection:$quality) { ForEach(["Low","Medium","High"],id:\.self){Text($0)} }.pickerStyle(.segmented); Button("BACK") { screen="" }.buttonStyle(.borderedProminent) }.padding(40).frame(maxWidth:480)
 } else {
 Image(slides[min(2,Int(progress*3))]).resizable().scaledToFill().frame(width:w,height:h).clipped().ignoresSafeArea()
 VStack { Spacer(); Text(progress < 1 ? "LOADING…" : "PRANK DEMO — NO GAMEPLAY").font(.headline); ProgressView(value:progress).tint(.white); Button("RETURN TO MENU") { screen="" }.buttonStyle(.bordered) }.padding(24).background(LinearGradient(colors:[.clear,.black.opacity(0.7)],startPoint:.top,endPoint:.bottom)).task { while progress < 1 && !Task.isCancelled { try? await Task.sleep(nanoseconds:250_000_000); if Task.isCancelled {break}; progress=min(1,progress+0.025) } }
 }
 }.foregroundColor(.white)
 }.statusBarHidden(true).persistentSystemOverlays(.hidden)
 }
 func tile(_ name:String,w:CGFloat,h:CGFloat)->some View {
 Button { selected=name;progress=0;screen=name } label: { Image(name).resizable().scaledToFill().frame(width:w,height:h).clipped().overlay(Rectangle().strokeBorder(selected == name ? Color.white : Color.white.opacity(0.2),lineWidth:selected == name ? 2 : 1)) }.buttonStyle(.plain).accessibilityLabel(name)
 }
}
